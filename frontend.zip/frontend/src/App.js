import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Navigation from './customer/components/Navigation/Navigation';
import HomePage from './pages/HomePage/HomePage';
import SignIn from './pages/LoginPage/SignIn';
import SignUp from "./pages/LoginPage/SignUp";
import Footer from './customer/components/Footer/Footer';
import Product from './customer/components/Product/Product';
import ProductDetails from "./customer/components/productDetails/ProductDetails";


export default function App() {
  return (
    <div className='bg-yellow-100'>


      <Navigation />
     
      <div>
        <BrowserRouter>
          <Routes>
              <Route path="/" element={<HomePage />}/>
              <Route path="signin" element={<SignIn />} />
              <Route path="signup" element={<SignUp />} />
              <Route path="product" element={<Product />} />
              <Route path="product/1" element={<ProductDetails  productId={1} />} />
              
          </Routes>
        </BrowserRouter>
      </div>
      <Footer />
    </div>

  ) 
}