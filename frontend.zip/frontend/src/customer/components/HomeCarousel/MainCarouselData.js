export const mainCarouselData = [
    {
        image: "https://www.casio.com/content/casio/locales/in/en/products/watches/gshock/products/analog-digital/_jcr_content/root/responsivegrid/teaser.casiocoreimg.jpeg/1670304325549/hero-pc.jpeg",
        path: "/unisex/watches/smartwatch"
    },
    {
        image: "https://m.media-amazon.com/images/I/61jzPPHm+kL._SY450_.jpg",
        path: "/unisex/watches/smartwatch"
    },
    {
        image: "https://m.media-amazon.com/images/I/61AHiYyu3ZL._SY450_.jpg",
        path: "/unisex/watches/smartwatch"
    },
    {
        image: "https://m.media-amazon.com/images/I/61JtVmcxb0L._SL1080_.jpg",
        path: "/unisex/watches/smartwatch"
    },
    {
        image: "https://m.media-amazon.com/images/I/61JtVmcxb0L._SL1080_.jpg",
        path: "/unisex/watches/smartwatch"
    }

]