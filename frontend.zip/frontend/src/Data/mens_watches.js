export const mens_watches=[
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Datetime",
        color:"green",
        discountedPrice:1999999,
        price: 2999999,
        discountPercent : 66,
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Chronograph",
        discountedPrice:1999999,
        color:"green",
        price: 4999999,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.casio.com/content/dam/casio/product-info/locales/in/en/timepiece/product/watch/G/GS/GST/gst-b100gb-1a9/assets/GST-B100GB-1A9.png.transform/main-visual-pc/image.png",
        brand:"Casio",
        title:"GST-B100GB-1A9",
        color:"gold",
        discountedPrice:9999,
        price: 29995,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwe485817b/images/Titan/Catalog/1802NL02_1.jpg?sw=800&sh=800",
        brand:"Titan",
        title:"Titan Workwear Green Dial Analog Leather Strap Watch for Men",
        color:"green",
        discountedPrice:1995,
        price: 2595,
        discountPercent : 66
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Datetime",
        color:"green",
        discountedPrice:1999999,
        price: 2999999,
        discountPercent : 66,
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Chronograph",
        color:"green",
        discountedPrice:1999999,
        price: 4999999,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.casio.com/content/dam/casio/product-info/locales/in/en/timepiece/product/watch/G/GS/GST/gst-b100gb-1a9/assets/GST-B100GB-1A9.png.transform/main-visual-pc/image.png",
        brand:"Casio",
        title:"GST-B100GB-1A9",
        color:"gold",
        discountedPrice:9999,
        price: 29995,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwe485817b/images/Titan/Catalog/1802NL02_1.jpg?sw=800&sh=800",
        brand:"Titan",
        title:"Titan Workwear Green Dial Analog Leather Strap Watch for Men",
        color:"green",
        discountedPrice:1999,
        price: 2595,
        discountPercent : 66
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Datetime",
        color:"green",
        discountedPrice:999995,
        price: 2999999,
        discountPercent : 66,
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Chronograph",
        color:"green",
        discountedPrice:1999999,
        price: 4999999,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.casio.com/content/dam/casio/product-info/locales/in/en/timepiece/product/watch/G/GS/GST/gst-b100gb-1a9/assets/GST-B100GB-1A9.png.transform/main-visual-pc/image.png",
        brand:"Casio",
        title:"GST-B100GB-1A9",
        color:"gold",
        discountedPrice:9999,
        price: 29995,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwe485817b/images/Titan/Catalog/1802NL02_1.jpg?sw=800&sh=800",
        brand:"Titan",
        title:"Titan Workwear Green Dial Analog Leather Strap Watch for Men",
        color:"green",
        discountedPrice:1595,
        price: 2595,
        discountPercent : 66
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Datetime",
        color:"green",
        discountedPrice:1999999,
        price: 2999999,
        discountPercent : 33,
    },
    {
        imageUrl: "https://imgs.search.brave.com/1sHkjz6zLxLDeSJTMuK2JBcz8VkkWjD1MIukp9ytTk0/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvNDU5/MDI1MzY1L3Bob3Rv/L3JvbGV4LWRheXRv/bmEtY29zbW9ncmFw/aC1veXN0ZXItcGVy/cGV0dWFsLXdoaXRl/LXN0ZWVsLmpwZz9z/PTYxMng2MTImdz0w/Jms9MjAmYz1kTVhy/a1Zia3NMQ245NWtX/VjU0czBKcmcyMG8t/TVljNWlwUUhMdWtt/Nm5NPQ",
        brand:"Rolex",
        title:"Chronograph",
        color:"green",
        discountedPrice:1699999,
        price: 4999999,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.casio.com/content/dam/casio/product-info/locales/in/en/timepiece/product/watch/G/GS/GST/gst-b100gb-1a9/assets/GST-B100GB-1A9.png.transform/main-visual-pc/image.png",
        brand:"Casio",
        title:"GST-B100GB-1A9",
        color:"gold",
        discountedPrice:9998,
        price: 29995,
        discountPercent : 66
    },
    {
        imageUrl: "https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dwe485817b/images/Titan/Catalog/1802NL02_1.jpg?sw=800&sh=800",
        brand:"Titan",
        title:"Titan Workwear Green Dial Analog Leather Strap Watch for Men",
        color:"green",
        discountedPrice:875,
        price: 2595,
        discountPercent : 66
    }


]